﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities.Models
{
    [Table("Supplier")]
    public class Suppliers
    {
        public Guid SupplierID { get; set; }
        [Required(ErrorMessage ="Supplier number is Required")]
        public int SupplierNumber { get; set; }
     
    }
}
