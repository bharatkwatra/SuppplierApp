﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities.Models
{
    [Table("SupplierRates")]
    public class SupplierRates
    {
        [Required(ErrorMessage = "Supplier number is Required")]
        public int SupplierNumber { get; set; }
        [Required(ErrorMessage = "Supplier Rate is Required")]
        public Decimal SupplierRate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [ForeignKey(nameof(Suppliers))]
        public Guid SupplierID { get; set; }
        public Suppliers Suppliers { get; set; }
    }
}
