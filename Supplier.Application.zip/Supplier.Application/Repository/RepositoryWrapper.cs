﻿using System;
using System.Collections.Generic;
using System.Text;
using Contracts;
using Entities;

namespace Repository
{
    public class RepositoryWrapper : IRepositoryWrapper 
    {
        private RepositoryContext _repoContext;
        private ISupplierRepository _supplier;
        private ISupplierRatesRepository _supplierrates;
        public ISupplierRepository Supplier
        {
            get {
                if (_supplier == null)
                {
                    _supplier = new SuppliersRepository(_repoContext);
                }
                return _supplier;
            }
        }
        public ISupplierRatesRepository SupplierRates
        {
            get {
                if (_supplierrates == null)
                {
                    _supplierrates = new SupplierRatesRepository(_repoContext);
                }
                return _supplierrates;
            }
        }
        public RepositoryWrapper(RepositoryContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }
        public void Save()
        {
            _repoContext.SaveChanges();
        }

    }
}
