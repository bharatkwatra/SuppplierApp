﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Contracts;
using Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Supplier.Application.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        
        private IRepositoryWrapper _repoWrapper;
       
        public WeatherForecastController(IRepositoryWrapper repoWrapper)
        {
            _repoWrapper = repoWrapper;
        }

        [HttpGet]
        [Route("api/WeatherForecast/GetAllSupplierRates")]
        public IEnumerable<SupplierRates> GetAllRates()
        {
            var SupplierRates = _repoWrapper.SupplierRates.FindAll();
            return SupplierRates;
        }

        [HttpGet]
        [Route("api/WeatherForecast/GetAllSupplierRates/Suppliernumber")]
        public IEnumerable<SupplierRates> GetSupplierRatebyID( int Suppliernumber)
        {
            var SupplierRates = _repoWrapper.SupplierRates.FindbyCondition(x => x.SupplierNumber.Equals(Suppliernumber));
            return SupplierRates;
        }
    }
}
