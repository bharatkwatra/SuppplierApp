﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts
{
    public interface IRepositoryWrapper
    {
        ISupplierRepository Supplier { get; }
        ISupplierRatesRepository SupplierRates { get; }
        void Save();
    }
}
